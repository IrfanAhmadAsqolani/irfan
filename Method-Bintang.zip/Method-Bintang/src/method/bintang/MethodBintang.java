package method.bintang;
import java.util.Scanner;

public class MethodBintang {

    public static void cetaksegitigabintang (){
        Scanner bintang = new Scanner(System.in);
        
        System.out.println("| soal segitiga bintang |");
        System.out.println("=========================");
        System.out.print("ukuran = ");
        
        int b1 = bintang.nextInt () ;
        System.out.println ("========================");
        
        for (int i = 1; i <= b1; i++) {
             for (int j= 1; j <= i; j++) {
                 System.out.print(" * ");
             }
             
             System.out.println (); 
        } 
    }
    
    public static void cetaksegiempatbintang (){
        Scanner bintang = new Scanner (System.in);
        
        System.out.println("| soal segiempat bintang |");
        System.out.println("=========================");
        System.out.print("ukuran = ");
        
        int b2 = bintang.nextInt () ;
        System.out.println ("========================");
        
        for (int i = 1; i <=b2; i++) {
            for (int j = 1; j <=b2; j++) {
                System.out.print(" * ");
            }
            
            System.out.println ();
            
        }
        System.out.println ("========================");
    }
    
    
    public static void main(String[] args) {
       
        Scanner bintang = new Scanner(System.in);
        
        System.out.println("**************************");
        System.out.println("* mencetak bangun bintang *");
        System.out.println("**************************");
        System.out.println("| 1. segitiga bintang |");
        System.out.println("| 1. segiempat bintang |");
        System.out.println("**************************");
        
        System.out.print("soal nomor : "); 
        
        int x = bintang.nextInt();
                
        if (x == 1) {
            System.out.println("==========================");
            cetaksegitigabintang();
            System.out.println("==========================");
        }else if (x==2){
            System.out.println("==========================");
            cetaksegiempatbintang();
            System.out.println("==========================");
        }else {
            System.out.println("maaf pilihan anda tidak ada!");
        }
    }
}