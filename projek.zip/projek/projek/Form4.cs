﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projek
{
    public partial class Form4 : Form
    {
        String pilih;
        Decimal hasil;
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtPanjang_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmdProses_Click(object sender, EventArgs e)
        {

        }

        private void cmdBatal_Click(object sender, EventArgs e)
        {
            txtLebar.Clear();
            txtPanjang.Clear();
            rdLuas.Checked = false;
            rdKeliling.Checked = false;
            txtPanjang.Focus();
            LHasil.Items.Clear();
            KHasil.Items.Clear();

        }

        private void rdLuas_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdLuas.Checked == true)
            {
                rdKeliling.Checked = false;
                pilih = "Luas";
                decimal panjang, lebar;
                panjang = Decimal.Parse(this.txtPanjang.Text);
                lebar = Decimal.Parse(this.txtLebar.Text);
                MessageBox.Show("rumus Luas Persegi Panjang adalah Panjang x Lebar");
                hasil = panjang * lebar;
                    LHasil.Items.Add(hasil);
            }
        }

        private void rdKeliling_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdKeliling.Checked == true)
            {

                rdLuas.Checked = false;
                pilih = "Keliling";
                decimal panjang, lebar;
                panjang = Decimal.Parse(this.txtPanjang.Text);
                lebar = Decimal.Parse(this.txtLebar.Text);
                MessageBox.Show("rumus keliling Persegi Panjang adalah (2 x Panjang) + (2 x Lebar)");
                hasil = ((2 * panjang) + (2 * lebar));
                    KHasil.Items.Add(hasil);
            }
        }

        private void cmdBack_Click(object sender, EventArgs e)
        {
            Menu f5 = new Menu();
            f5.Show();
            this.Hide();
        }

        private void KHasil_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
