﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projek
{
    public partial class Form1 : Form
    {
        String pilih;
        Decimal hasil;

        public Form1()
        {
            InitializeComponent();
        }

        private void cmdProses_Click(object sender, EventArgs e)
        {
            
        }

        private void rdKeliling_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdKeliling.Checked == true)
            {
                rdLuas.Checked = false;
                pilih = "Keliling";
                decimal Sisi;
                Sisi = Decimal.Parse(this.txtSisi.Text);
                MessageBox.Show("rumus keliling Persegi adalah 4 x S");
                hasil = 4 * Sisi;
                    KHasil.Items.Add(hasil);
            }
        }

        private void rdLuas_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdLuas.Checked == true)
            {
                rdKeliling.Checked = false;
                pilih = "Luas";
                decimal Sisi;
                Sisi = Decimal.Parse(this.txtSisi.Text);
                MessageBox.Show("rumus Luas Persegi adalah S x S");
                hasil = Sisi * Sisi;
                    LHasil.Items.Add(hasil);

                
            }
        }

        private void cmdBatal_Click(object sender, EventArgs e)
        {
            txtSisi.Clear();
            rdLuas.Checked = false;
            rdKeliling.Checked = false;
            txtSisi.Focus();
            LHasil.Items.Clear();
            KHasil.Items.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cmdBack_Click(object sender, EventArgs e)
        {
            Menu f2 = new Menu();
            f2.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void KHasil_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
