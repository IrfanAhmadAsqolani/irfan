﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projek
{
    public partial class Form3 : Form
    {
        String pilih;
        Decimal hasil;
        public Form3()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void rdKeliling_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdKeliling.Checked == true)
            {
                rdLuas.Checked = false;
                pilih = "Keliling";
                decimal D1, D2, Simi;
                D1 = Decimal.Parse(this.txtD1.Text);
                D2 = Decimal.Parse(this.txtD2.Text);
                Simi = Decimal.Parse(this.txtSimi.Text);
                MessageBox.Show("rumus keliling Belah Ketupat adalah 4 x sisi miring");
                hasil = 4 * Simi;
                    KHasil.Items.Add(hasil);
            }
        }

        private void rdLuas_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdLuas.Checked == true)
            {
                rdKeliling.Checked = false;
                pilih = "Luas";
                decimal D1, D2, Simi;
                D1 = Decimal.Parse(this.txtD1.Text);
                D2 = Decimal.Parse(this.txtD2.Text);
                Simi = Decimal.Parse(this.txtSimi.Text);
                MessageBox.Show("rumus Luas Belah Ketupat adalah d1 X d2 /2");
                hasil = D1 * D2 / 2;
                    LHasil.Items.Add(hasil);
            }
        }

        private void cmdBack_Click(object sender, EventArgs e)
        {
            Menu f4 = new Menu();
            f4.Show();
            this.Hide();
        }

        private void cmdProses_Click(object sender, EventArgs e)
        {
            
        }

        private void cmdBatal_Click(object sender, EventArgs e)
        {
            txtD1.Clear();
            txtD2.Clear();
            txtSimi.Clear();
            rdLuas.Checked = false;
            rdKeliling.Checked = false;
            txtD1.Focus();
            LHasil.Items.Clear();
            KHasil.Items.Clear();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
