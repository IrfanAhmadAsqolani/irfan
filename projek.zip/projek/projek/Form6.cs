﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projek
{
    public partial class Form6 : Form
    {
        String pilih;
        Decimal hasil;
        public Form6()
        {
            InitializeComponent();
        }

        private void rdKeliling_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdKeliling.Checked == true)
            {
                rdLuas.Checked = false;
                pilih = "Keliling";
                decimal D1, D2, S1, S2;
                D1 = Decimal.Parse(this.txtD1.Text);
                D2 = Decimal.Parse(this.txtD2.Text);
                S1 = Decimal.Parse(this.txtS1.Text);
                S2 = Decimal.Parse(this.txtS2.Text);
                MessageBox.Show("rumus keliling Layang-Layang adalah 2 x (S1 + S2)");
                hasil = 2 * (S1 + S2);
                    KHasil.Items.Add(hasil);

            }
        }

        private void rdLuas_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdLuas.Checked == true)
            {
                rdKeliling.Checked = false;
                pilih = "Luas";
                decimal D1, D2, S1, S2;
                D1 = Decimal.Parse(this.txtD1.Text);
                D2 = Decimal.Parse(this.txtD2.Text);
                S1 = Decimal.Parse(this.txtS1.Text);
                S2 = Decimal.Parse(this.txtS2.Text);
                MessageBox.Show("rumus Luas Layang-Layang adalah D1 X D2/2");
                hasil = D1 * D2 / 2;
                    LHasil.Items.Add(hasil);
            }
        }

        private void cmdProses_Click(object sender, EventArgs e)
        {

        }

        private void cmdBack_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            menu.Show();
            this.Hide();
        }

        private void cmdBatal_Click(object sender, EventArgs e)
        {
            txtD1.Clear();
            txtD2.Clear();
            txtS1.Clear();
            txtS2.Clear();
            rdLuas.Checked = false;
            rdKeliling.Checked = false;
            txtD1.Focus();
            LHasil.Items.Clear();
            KHasil.Items.Clear();
        }
    }
}
