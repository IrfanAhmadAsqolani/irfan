﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projek
{
    public partial class Form2 : Form
    {
        String pilih;
        Double hasil;
        public Form2()
        {
            InitializeComponent();
        }

        private void rdKeliling_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdKeliling.Checked == true)
            {
                rdLuas.Checked = false;
                pilih = "Keliling";
                double Jari;
                Jari = Double.Parse(this.txtJari.Text);
                MessageBox.Show("rumus keliling Lingkaran adalah 2 x 3,14 x jari-jari");
                hasil = 2 * 3.14 * Jari;
                KHasil.Items.Add(hasil);
            }
        }

        private void rdLuas_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdLuas.Checked == true)
            {
                rdKeliling.Checked = false;
                pilih = "Luas";
                double Jari;
                Jari = Double.Parse(this.txtJari.Text);
                MessageBox.Show("rumus Luas Lingkaran adalah 3,14 x jari-jari");
                hasil = 3.14 * Jari * Jari;
                    LHasil.Items.Add(hasil);
            }
        }

        private void cmdBatal_Click(object sender, EventArgs e)
        {
            txtJari.Clear();
            rdLuas.Checked = false;
            rdKeliling.Checked = false;
            txtJari.Focus();
            LHasil.Items.Clear();
            KHasil.Items.Clear();
        }

        private void cmdProses_Click(object sender, EventArgs e)
        {
            
        }

        private void cmdBack_Click(object sender, EventArgs e)
        {
            Menu f3 = new Menu();
            f3.Show();
            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void fHitung_load_Click(object sender, EventArgs e)
        {

        }
    }
}
