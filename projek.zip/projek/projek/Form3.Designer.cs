﻿namespace projek
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.cmdBack = new System.Windows.Forms.Button();
            this.LHasil = new System.Windows.Forms.ListBox();
            this.KHasil = new System.Windows.Forms.ListBox();
            this.rdLuas = new System.Windows.Forms.RadioButton();
            this.rdKeliling = new System.Windows.Forms.RadioButton();
            this.cmdBatal = new System.Windows.Forms.Button();
            this.txtD2 = new System.Windows.Forms.TextBox();
            this.txtD1 = new System.Windows.Forms.TextBox();
            this.fHitung_load = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSimi = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdBack
            // 
            this.cmdBack.ForeColor = System.Drawing.Color.Blue;
            this.cmdBack.Location = new System.Drawing.Point(192, 328);
            this.cmdBack.Name = "cmdBack";
            this.cmdBack.Size = new System.Drawing.Size(75, 23);
            this.cmdBack.TabIndex = 38;
            this.cmdBack.Text = "Back";
            this.cmdBack.UseVisualStyleBackColor = true;
            this.cmdBack.Click += new System.EventHandler(this.cmdBack_Click);
            // 
            // LHasil
            // 
            this.LHasil.FormattingEnabled = true;
            this.LHasil.Location = new System.Drawing.Point(157, 206);
            this.LHasil.Name = "LHasil";
            this.LHasil.Size = new System.Drawing.Size(127, 17);
            this.LHasil.TabIndex = 37;
            // 
            // KHasil
            // 
            this.KHasil.FormattingEnabled = true;
            this.KHasil.Location = new System.Drawing.Point(157, 173);
            this.KHasil.Name = "KHasil";
            this.KHasil.Size = new System.Drawing.Size(127, 17);
            this.KHasil.TabIndex = 36;
            // 
            // rdLuas
            // 
            this.rdLuas.AutoSize = true;
            this.rdLuas.BackColor = System.Drawing.Color.Transparent;
            this.rdLuas.ForeColor = System.Drawing.Color.White;
            this.rdLuas.Location = new System.Drawing.Point(79, 206);
            this.rdLuas.Name = "rdLuas";
            this.rdLuas.Size = new System.Drawing.Size(48, 17);
            this.rdLuas.TabIndex = 35;
            this.rdLuas.TabStop = true;
            this.rdLuas.Text = "Luas";
            this.rdLuas.UseVisualStyleBackColor = false;
            this.rdLuas.CheckedChanged += new System.EventHandler(this.rdLuas_CheckedChanged);
            // 
            // rdKeliling
            // 
            this.rdKeliling.AutoSize = true;
            this.rdKeliling.BackColor = System.Drawing.Color.Transparent;
            this.rdKeliling.ForeColor = System.Drawing.Color.White;
            this.rdKeliling.Location = new System.Drawing.Point(79, 173);
            this.rdKeliling.Name = "rdKeliling";
            this.rdKeliling.Size = new System.Drawing.Size(58, 17);
            this.rdKeliling.TabIndex = 34;
            this.rdKeliling.TabStop = true;
            this.rdKeliling.Text = "Keliling";
            this.rdKeliling.UseVisualStyleBackColor = false;
            this.rdKeliling.CheckedChanged += new System.EventHandler(this.rdKeliling_CheckedChanged);
            // 
            // cmdBatal
            // 
            this.cmdBatal.ForeColor = System.Drawing.Color.Blue;
            this.cmdBatal.Location = new System.Drawing.Point(192, 276);
            this.cmdBatal.Name = "cmdBatal";
            this.cmdBatal.Size = new System.Drawing.Size(75, 23);
            this.cmdBatal.TabIndex = 33;
            this.cmdBatal.Text = "Reset";
            this.cmdBatal.UseVisualStyleBackColor = true;
            this.cmdBatal.Click += new System.EventHandler(this.cmdBatal_Click);
            // 
            // txtD2
            // 
            this.txtD2.Location = new System.Drawing.Point(157, 103);
            this.txtD2.Name = "txtD2";
            this.txtD2.Size = new System.Drawing.Size(127, 20);
            this.txtD2.TabIndex = 31;
            // 
            // txtD1
            // 
            this.txtD1.Location = new System.Drawing.Point(157, 71);
            this.txtD1.Name = "txtD1";
            this.txtD1.Size = new System.Drawing.Size(127, 20);
            this.txtD1.TabIndex = 30;
            // 
            // fHitung_load
            // 
            this.fHitung_load.AutoSize = true;
            this.fHitung_load.BackColor = System.Drawing.Color.Transparent;
            this.fHitung_load.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fHitung_load.ForeColor = System.Drawing.Color.White;
            this.fHitung_load.Location = new System.Drawing.Point(18, 185);
            this.fHitung_load.Name = "fHitung_load";
            this.fHitung_load.Size = new System.Drawing.Size(46, 16);
            this.fHitung_load.TabIndex = 29;
            this.fHitung_load.Text = "Hitung";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(18, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "Masukan Diagonal 2";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(18, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Masukan Diagonal 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(84, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 19);
            this.label1.TabIndex = 26;
            this.label1.Text = "BELAH KETUPAT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(18, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 13);
            this.label4.TabIndex = 39;
            this.label4.Text = "Masukan Sisi Miring";
            // 
            // txtSimi
            // 
            this.txtSimi.Location = new System.Drawing.Point(157, 136);
            this.txtSimi.Name = "txtSimi";
            this.txtSimi.Size = new System.Drawing.Size(127, 20);
            this.txtSimi.TabIndex = 40;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(21, 229);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(153, 151);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lime;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(302, 387);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtSimi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmdBack);
            this.Controls.Add(this.LHasil);
            this.Controls.Add(this.KHasil);
            this.Controls.Add(this.rdLuas);
            this.Controls.Add(this.rdKeliling);
            this.Controls.Add(this.cmdBatal);
            this.Controls.Add(this.txtD2);
            this.Controls.Add(this.txtD1);
            this.Controls.Add(this.fHitung_load);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.Aqua;
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdBack;
        private System.Windows.Forms.ListBox LHasil;
        private System.Windows.Forms.ListBox KHasil;
        private System.Windows.Forms.RadioButton rdLuas;
        private System.Windows.Forms.RadioButton rdKeliling;
        private System.Windows.Forms.Button cmdBatal;
        private System.Windows.Forms.TextBox txtD2;
        private System.Windows.Forms.TextBox txtD1;
        private System.Windows.Forms.Label fHitung_load;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSimi;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}