﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projek
{
    public partial class Form5 : Form
    {
        String pilih;
        Decimal hasil;
        public Form5()
        {
            InitializeComponent();
        }

        private void rdKeliling_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdKeliling.Checked == true)
            {
                rdLuas.Checked = false;
                pilih = "Keliling";
                decimal Alas, Tinggi, Simi;
                Alas = Decimal.Parse(this.txtAlas.Text);
                Tinggi = Decimal.Parse(this.txtTinggi.Text);
                Simi = Decimal.Parse(this.txtSimi.Text);
                MessageBox.Show("rumus keliling Jajar Genjang adalah 2 x (Alas + Sisi Miring)");
                hasil = 2 * (Alas + Simi);
                    KHasil.Items.Add(hasil);
            }
        }

        private void rdLuas_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdLuas.Checked == true)
            {
                rdKeliling.Checked = false;
                pilih = "Luas";
                decimal Alas, Tinggi, Simi;
                Alas = Decimal.Parse(this.txtAlas.Text);
                Tinggi = Decimal.Parse(this.txtTinggi.Text);
                Simi = Decimal.Parse(this.txtSimi.Text);
                MessageBox.Show("rumus Luas Jajar Genjang adalah Alas x Tinggi");
                hasil = Alas * Tinggi;
                    LHasil.Items.Add(hasil);
            }
        }

        private void cmdBack_Click(object sender, EventArgs e)
        {
            Menu f6 = new Menu();
            f6.Show();
            this.Hide();
        }

        private void cmdProses_Click(object sender, EventArgs e)
        {
            
        }

        private void cmdBatal_Click(object sender, EventArgs e)
        {
            txtAlas.Clear();
            txtTinggi.Clear();
            txtSimi.Clear();
            rdLuas.Checked = false;
            rdKeliling.Checked = false;
            txtAlas.Focus();
            LHasil.Items.Clear();
            KHasil.Items.Clear();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
