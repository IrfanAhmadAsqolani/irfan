﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projek
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void login_Load(object sender, EventArgs e)
        {
            
        }

        private void blogin_Click(object sender, EventArgs e)
        {
            String username = txtuser.Text;
            String password = txtpassword.Text;
            string login = cblogin.Text;
            if (username.Equals("atikah") && password.Equals("tikah") && cblogin.Text.Equals("Atikah Hijriyanah"))
            {
                MessageBox.Show("selamat datang" + "\nusername:" + username + "\npassword: " + password + "\nlogin as:" + login);
                Menu main = new Menu();
                main.Show();
                this.Hide();
            }
            else if (username.Equals("bagas") && password.Equals("22091998") && cblogin.Text.Equals("Bagas Alfito Prismawan"))
            {
                MessageBox.Show("selamat datang" + "\nusername:" + username + "\npassword: " + password + "\nlogin as:" + login);
                Menu main = new Menu();
                main.Show();
                this.Hide();
            }
            else if (username.Equals("irfan") && password.Equals("ahmad") && cblogin.Text.Equals("Irfan Ahmad Asqolani"))
            {
                MessageBox.Show("selamat datang" + "\nusername:" + username + "\npassword: " + password + "\nlogin as:" + login);
                Menu main = new Menu();
                main.Show();
                this.Hide();
            }
            else if (username.Equals("suci") && password.Equals("sofyati") && cblogin.Text.Equals("Suci Sofyati"))
            {
                MessageBox.Show("selamat datang" + "\nusername:" + username + "\npassword: " + password + "\nlogin as:" + login);
                Menu main = new Menu();
                main.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Periksa kembali");
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }
    }
    }

