package palindrom;
import java.util.Scanner;
public class Palindrom {
    public static void main(String[] args) {
     Scanner input = new Scanner(System.in);
        String inputan = input.nextLine();
        String dibalik = new StringBuffer(inputan).reverse().toString();
        if(inputan.equalsIgnoreCase(dibalik)){
            System.out.println("Ini merupakan palindrom dan jumlah kata: "+inputan.length());
        }
        else{
            System.out.println("Ini bukan palindrom dan jumlah kata: "+inputan.length());
        }   
    }
}