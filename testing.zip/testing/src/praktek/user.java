/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package praktek;

/**
 *
 * @author user
 */
public class user {
    private String reguser;
    private String regpass;
    
    public user(String reguser, String regpass)
    {
        this.reguser=reguser;
        this.regpass=regpass;
    }
    public String getreguser()
    {
        return reguser;
    }
    public String getpass()
    {
        return regpass;
    }
}
