
package praktek;
import com.mysql.jdbc.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;

public class db {

    com.mysql.jdbc.Connection con = null;
    PreparedStatement ps ;
    private static com.mysql.jdbc.Connection db;
    public static com.mysql.jdbc.Connection java_db(){
       try {
    String url = "jdbc:mysql://localhost:3306/praktek";
    String user = "root";
    String password = "";
    
    DriverManager.registerDriver(new com.mysql.jdbc.Driver());
    db=(com.mysql.jdbc.Connection) DriverManager.getConnection(url, user, password);
} 
    catch(Exception e){
    System.err.println("Koneksi gagal"+e.getMessage());
}
        return db;
    }
}         