package segitiga.samping;
import java.util.Scanner;
public class SegitigaSamping {
    public static void main(String[] args) {
        System.out.println("**************************");
        System.out.println("* mencetak bangun segitiga bintang *");
        System.out.println("**************************");
        System.out.print("ukuran = ");
         Scanner bintang = new Scanner(System.in);
         int b1 = bintang.nextInt () ;
        System.out.println ("========================");
             
             for (int i = 1; i <= b1; i++) {
             for (int j= 1; j <= i; j++) {
                 System.out.print(" * ");
             }
                     
             System.out.println ();
        }
        for (int i = 1; i <=b1+1; i++){
            for (int k = b1-1; k >= i; k--){
                System.out.print(" * ");
        }
         System.out.println ();
        } 
    }
}
