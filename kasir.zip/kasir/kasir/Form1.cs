﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kasir
{
    public partial class Form1 : Form
    {
        CheckBox[] pilihan = new CheckBox[6];
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pilihan [0] = checkBox1;
            pilihan [1] = checkBox2;
            pilihan [2] = checkBox3;
            pilihan [3] = checkBox4;
            pilihan [4] = checkBox5;
            pilihan [5] = checkBox6;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int harga = 5000;
            int total = 0;
            int i;
            for (i=0; i < pilihan.Length; i++)
            {
                if (pilihan[i].Checked)
                {
                    total = total + harga;
                }
                harga = harga + 1000;
            }
            textBox1.Text = total.ToString();
        }
    }
}
