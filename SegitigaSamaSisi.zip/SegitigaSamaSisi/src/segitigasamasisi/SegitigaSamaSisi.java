package segitigasamasisi;
import java.util.Scanner;
public class SegitigaSamaSisi {
    public static void main(String[] args) {
         System.out.println("**************************");
        System.out.println("* mencetak bangun segitiga bintang *");
        System.out.println("**************************");
        System.out.print("ukuran = ");
         Scanner bintang = new Scanner(System.in);
         int b2 = bintang.nextInt () ;
        System.out.println ("========================");
        
        for (int a = 1; a <= b2; a++) {
             for (int b= (b2-1); b >= a; b--) {
                 System.out.print("   ");
             }
             for (int c= 1; c <=a; c++){
                 System.out.print(" * ");
             }
             for (int j= 1; j <= a-1; j++) {
                 System.out.print(" * ");
             }
             System.out.println ();
          
       }
    }
}
