﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas
{
    public partial class TambahSiswa : Form
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public TambahSiswa()
        {
            InitializeComponent();
        }

        private void SubmitGuru_Click(object sender, EventArgs e)
        {
            Siswa pl = new Siswa();

            pl.NISN = int.Parse(txtNISN.Text);
            pl.Nama = txtNama.Text;
            pl.Kelas = txtKelas.Text;
            pl.Jurusan = txtJurusan.Text;
            pl.Jenis_Kelamin = txtJK.Text;
            db.Siswas.InsertOnSubmit(pl);

            db.SubmitChanges();
            MessageBox.Show("Data berhasil di simpan");
            txtNISN.Clear();
            txtNama.Clear();
            
        }

        private void Back_Click(object sender, EventArgs e)
        {

            this.Hide();
        }
    }
}
