﻿namespace tugas
{
    partial class TambahPoint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TambahPoint));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.SubmitPoint = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtNISN = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Back = new System.Windows.Forms.Button();
            this.txtKodpel = new System.Windows.Forms.ComboBox();
            this.pointBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pointDataSet1 = new tugas.pointDataSet1();
            this.pointDataSet = new tugas.pointDataSet();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pointTableAdapter = new tugas.pointDataSetTableAdapters.PointTableAdapter();
            this.pointTableAdapter1 = new tugas.pointDataSet1TableAdapters.PointTableAdapter();
            this.sambung = new tugas.sambung();
            this.pointBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pointTableAdapter2 = new tugas.sambungTableAdapters.PointTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sambung)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(694, 38);
            this.panel1.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(191, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(312, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Penambahan Data Pelanggaran";
            // 
            // SubmitPoint
            // 
            this.SubmitPoint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.SubmitPoint.FlatAppearance.BorderSize = 0;
            this.SubmitPoint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SubmitPoint.Location = new System.Drawing.Point(558, 246);
            this.SubmitPoint.Name = "SubmitPoint";
            this.SubmitPoint.Size = new System.Drawing.Size(94, 23);
            this.SubmitPoint.TabIndex = 31;
            this.SubmitPoint.Text = "Submit";
            this.SubmitPoint.UseVisualStyleBackColor = false;
            this.SubmitPoint.Click += new System.EventHandler(this.SubmitPoint_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(430, 207);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(222, 20);
            this.dateTimePicker1.TabIndex = 30;
            // 
            // txtNISN
            // 
            this.txtNISN.Location = new System.Drawing.Point(430, 165);
            this.txtNISN.Name = "txtNISN";
            this.txtNISN.Size = new System.Drawing.Size(222, 20);
            this.txtNISN.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(237, 207);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 22);
            this.label4.TabIndex = 27;
            this.label4.Text = "Waktu Kejadian";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(237, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 22);
            this.label3.TabIndex = 26;
            this.label3.Text = "NISN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(237, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 22);
            this.label2.TabIndex = 25;
            this.label2.Text = "Kode Pelanggaran";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(41, 94);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(165, 199);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.Back.FlatAppearance.BorderSize = 0;
            this.Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Back.Location = new System.Drawing.Point(430, 246);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(95, 23);
            this.Back.TabIndex = 41;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // txtKodpel
            // 
            this.txtKodpel.FormattingEnabled = true;
            this.txtKodpel.Items.AddRange(new object[] {
            "A101",
            "A102",
            "A103",
            "A104",
            "A105",
            "A106",
            "A107",
            "A108",
            "A201",
            "A202",
            "A203",
            "A204",
            "A205",
            "A206",
            "A301",
            "A401",
            "A501",
            "B101",
            "B102",
            "B103",
            "B104",
            "B105",
            "B201",
            "B202",
            "B203",
            "B204",
            "B205",
            "B206",
            "B207",
            "B208",
            "C001",
            "C002",
            "C003",
            "C004",
            "C005",
            "C006",
            "C007",
            "C008",
            "C009",
            "C010",
            "C011",
            "C012",
            "C013",
            "C014",
            "C015",
            "C016",
            "C017",
            "C018",
            "C019",
            "C020",
            "C021",
            "C022",
            "C023",
            "C024",
            "C025",
            "C026",
            "C027",
            "C028",
            "C029",
            "C030",
            "C031",
            "C032",
            "C033",
            "C034",
            "C035",
            "C036",
            "C037",
            "C038",
            "C039"});
            this.txtKodpel.Location = new System.Drawing.Point(430, 124);
            this.txtKodpel.Name = "txtKodpel";
            this.txtKodpel.Size = new System.Drawing.Size(222, 21);
            this.txtKodpel.TabIndex = 42;
            this.txtKodpel.ValueMember = "Point.Kode_Pelanggaran";
            this.txtKodpel.SelectedIndexChanged += new System.EventHandler(this.txtKodpel_SelectedIndexChanged);
            // 
            // pointBindingSource
            // 
            this.pointBindingSource.DataMember = "Point";
            this.pointBindingSource.DataSource = this.pointDataSet1;
            // 
            // pointDataSet1
            // 
            this.pointDataSet1.DataSetName = "pointDataSet1";
            this.pointDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pointDataSet
            // 
            this.pointDataSet.DataSetName = "pointDataSet";
            this.pointDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataMember = "Point";
            this.bindingSource1.DataSource = this.pointDataSet;
            // 
            // pointTableAdapter
            // 
            this.pointTableAdapter.ClearBeforeFill = true;
            // 
            // pointTableAdapter1
            // 
            this.pointTableAdapter1.ClearBeforeFill = true;
            // 
            // sambung
            // 
            this.sambung.DataSetName = "sambung";
            this.sambung.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pointBindingSource1
            // 
            this.pointBindingSource1.DataMember = "Point";
            this.pointBindingSource1.DataSource = this.sambung;
            // 
            // pointTableAdapter2
            // 
            this.pointTableAdapter2.ClearBeforeFill = true;
            // 
            // TambahPoint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(694, 350);
            this.Controls.Add(this.txtKodpel);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.SubmitPoint);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtNISN);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TambahPoint";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.TambahPoint_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sambung)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SubmitPoint;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txtNISN;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.ComboBox txtKodpel;
        private pointDataSet pointDataSet;
        private System.Windows.Forms.BindingSource bindingSource1;
        private pointDataSetTableAdapters.PointTableAdapter pointTableAdapter;
        private pointDataSet1 pointDataSet1;
        private System.Windows.Forms.BindingSource pointBindingSource;
        private pointDataSet1TableAdapters.PointTableAdapter pointTableAdapter1;
        private sambung sambung;
        private System.Windows.Forms.BindingSource pointBindingSource1;
        private sambungTableAdapters.PointTableAdapter pointTableAdapter2;
    }
}