﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas
{
    public partial class AddControl : UserControl
    {
        public AddControl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TambahSiswa d = new TambahSiswa();
            d.Show();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TambahGuru d = new TambahGuru();
            d.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TambahPoint d = new TambahPoint();
            d.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            TambahLaporan d = new TambahLaporan();
            d.Show();
        }
    }
}
