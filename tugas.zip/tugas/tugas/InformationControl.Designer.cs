﻿namespace tugas
{
    partial class InformationControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buttonLaporan = new System.Windows.Forms.Button();
            this.buttonSiswa = new System.Windows.Forms.Button();
            this.buttonPelanggaran = new System.Windows.Forms.Button();
            this.buttonGuru = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(218, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(278, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "Informasi Aplikasi Point Siswa";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(694, 38);
            this.panel1.TabIndex = 6;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(32, 87);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(529, 239);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // buttonLaporan
            // 
            this.buttonLaporan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.buttonLaporan.FlatAppearance.BorderSize = 0;
            this.buttonLaporan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLaporan.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLaporan.ForeColor = System.Drawing.Color.White;
            this.buttonLaporan.Location = new System.Drawing.Point(579, 120);
            this.buttonLaporan.Name = "buttonLaporan";
            this.buttonLaporan.Size = new System.Drawing.Size(99, 23);
            this.buttonLaporan.TabIndex = 7;
            this.buttonLaporan.Text = "Laporan";
            this.buttonLaporan.UseVisualStyleBackColor = false;
            this.buttonLaporan.Click += new System.EventHandler(this.buttonLaporan_Click);
            // 
            // buttonSiswa
            // 
            this.buttonSiswa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.buttonSiswa.FlatAppearance.BorderSize = 0;
            this.buttonSiswa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSiswa.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSiswa.ForeColor = System.Drawing.Color.White;
            this.buttonSiswa.Location = new System.Drawing.Point(579, 158);
            this.buttonSiswa.Name = "buttonSiswa";
            this.buttonSiswa.Size = new System.Drawing.Size(99, 23);
            this.buttonSiswa.TabIndex = 8;
            this.buttonSiswa.Text = "Siswa";
            this.buttonSiswa.UseVisualStyleBackColor = false;
            this.buttonSiswa.Click += new System.EventHandler(this.buttonSiswa_Click);
            // 
            // buttonPelanggaran
            // 
            this.buttonPelanggaran.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.buttonPelanggaran.FlatAppearance.BorderSize = 0;
            this.buttonPelanggaran.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPelanggaran.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPelanggaran.ForeColor = System.Drawing.Color.White;
            this.buttonPelanggaran.Location = new System.Drawing.Point(579, 234);
            this.buttonPelanggaran.Name = "buttonPelanggaran";
            this.buttonPelanggaran.Size = new System.Drawing.Size(99, 23);
            this.buttonPelanggaran.TabIndex = 10;
            this.buttonPelanggaran.Text = "Pelanggaran";
            this.buttonPelanggaran.UseVisualStyleBackColor = false;
            this.buttonPelanggaran.Click += new System.EventHandler(this.buttonPelanggaran_Click);
            // 
            // buttonGuru
            // 
            this.buttonGuru.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.buttonGuru.FlatAppearance.BorderSize = 0;
            this.buttonGuru.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonGuru.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGuru.ForeColor = System.Drawing.Color.White;
            this.buttonGuru.Location = new System.Drawing.Point(579, 196);
            this.buttonGuru.Name = "buttonGuru";
            this.buttonGuru.Size = new System.Drawing.Size(99, 23);
            this.buttonGuru.TabIndex = 11;
            this.buttonGuru.Text = "Guru";
            this.buttonGuru.UseVisualStyleBackColor = false;
            this.buttonGuru.Click += new System.EventHandler(this.buttonGuru_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(99, 59);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(186, 20);
            this.textBox1.TabIndex = 12;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(29, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "Search ";
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.buttonDelete.FlatAppearance.BorderSize = 0;
            this.buttonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDelete.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDelete.ForeColor = System.Drawing.Color.White;
            this.buttonDelete.Location = new System.Drawing.Point(579, 272);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(99, 23);
            this.buttonDelete.TabIndex = 15;
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // InformationControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.buttonGuru);
            this.Controls.Add(this.buttonPelanggaran);
            this.Controls.Add(this.buttonSiswa);
            this.Controls.Add(this.buttonLaporan);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "InformationControl";
            this.Size = new System.Drawing.Size(694, 350);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonLaporan;
        private System.Windows.Forms.Button buttonSiswa;
        private System.Windows.Forms.Button buttonPelanggaran;
        private System.Windows.Forms.Button buttonGuru;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonDelete;
    }
}
