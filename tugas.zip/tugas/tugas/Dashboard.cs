﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas
{
    public partial class Dashboard : Form
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public Dashboard()
        {
            InitializeComponent();
            panel5.Height = buttonHome.Height;
            panel5.Top = buttonHome.Top;
            homeControl1.BringToFront();
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            panel5.Height = buttonHome.Height;
            panel5.Top = buttonHome.Top;
            homeControl1.BringToFront();
        }

        private void buttonPoint_Click(object sender, EventArgs e)
        {
            panel5.Height = buttonPoint.Height;
            panel5.Top = buttonPoint.Top;
            pointControl1.BringToFront();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            panel5.Height = buttonAdd.Height;
            panel5.Top = buttonAdd.Top;
            addControl1.BringToFront();
        }

        private void buttonInformation_Click(object sender, EventArgs e)
        {
            panel5.Height = buttonInformation.Height;
            panel5.Top = buttonInformation.Top;
            informationControl1.BringToFront();
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            panel5.Height = buttonReset.Height;
            panel5.Top = buttonReset.Top;
            DialogResult result = MessageBox.Show("Anda yakin ingin menghapus point pelanggaran?", "Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                DialogResult apus = MessageBox.Show("point pelanggaran akan terhapus secara permanen?", "Confirmation", MessageBoxButtons.YesNo);
                if (apus == DialogResult.Yes)
                {
                    db = new DataClasses1DataContext();
                    var p = from o in db.Pelanggarans select o;

                    db.Pelanggarans.DeleteAllOnSubmit(p);
                    db.SubmitChanges();
                    MessageBox.Show("Point Berhasil di hapus");
                }
                else if (apus == DialogResult.No)
                {

                }
            }else if (result == DialogResult.No)
            {

            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Anda yakin ingin Log out?", "Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Form1 d = new Form1();
                d.Show();
                this.Hide();
            }
            else if (result == DialogResult.No)
            {
                
            }
            
        }

        private void Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Anda yakin ingin menutup aplikasi?", "Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (result == DialogResult.No)
            {
                
            }
            
        }

        private void Maximize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            Restore.Visible = true;
            Maximize.Visible = false;
        }

        private void Restore_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            Maximize.Visible = true;
            Restore.Visible = false;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
