﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace tugas
{
    
    public partial class TambahPoint : Form
    {
        public static SqlConnection con = new SqlConnection(@"Data Source=desktop-ujmhqsc\sqlexpress;Initial Catalog=revisi;Integrated Security=True");
        DataClasses1DataContext db = new DataClasses1DataContext();
        public TambahPoint()
        {            
            InitializeComponent();
        }

        private void SubmitPoint_Click(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            Pelanggaran pl = new Pelanggaran();
            
            pl.Kode_Pelanggaran = txtKodpel.Text;
            pl.NISN = int.Parse(txtNISN.Text);
            pl.Waktu_Kejadian = DateTime.Parse(dateTimePicker1.Text);
            db.Pelanggarans.InsertOnSubmit(pl);

            db.SubmitChanges();
            MessageBox.Show("Data berhasil di simpan");            
            txtNISN.Clear();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void TambahPoint_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sambung.Point' table. You can move, or remove it, as needed.
            this.pointTableAdapter2.Fill(this.sambung.Point);
            // TODO: This line of code loads data into the 'pointDataSet1.Point' table. You can move, or remove it, as needed.
            this.pointTableAdapter1.Fill(this.pointDataSet1.Point);
            // TODO: This line of code loads data into the 'pointDataSet.Point' table. You can move, or remove it, as needed.
            this.pointTableAdapter.Fill(this.pointDataSet.Point);
            
            
        }

        private void txtKodpel_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
