﻿namespace tugas
{
    partial class TambahSiswa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TambahSiswa));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.SubmitGuru = new System.Windows.Forms.Button();
            this.txtNama = new System.Windows.Forms.TextBox();
            this.txtNISN = new System.Windows.Forms.TextBox();
            this.txtHari_Piket = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNam = new System.Windows.Forms.Label();
            this.txtaja = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Back = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtKelas = new System.Windows.Forms.ComboBox();
            this.txtJK = new System.Windows.Forms.ComboBox();
            this.txtJurusan = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(694, 38);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(220, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(242, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Penambahan Data Siswa";
            // 
            // SubmitGuru
            // 
            this.SubmitGuru.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.SubmitGuru.FlatAppearance.BorderSize = 0;
            this.SubmitGuru.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SubmitGuru.Location = new System.Drawing.Point(534, 291);
            this.SubmitGuru.Name = "SubmitGuru";
            this.SubmitGuru.Size = new System.Drawing.Size(94, 23);
            this.SubmitGuru.TabIndex = 23;
            this.SubmitGuru.Text = "Submit";
            this.SubmitGuru.UseVisualStyleBackColor = false;
            this.SubmitGuru.Click += new System.EventHandler(this.SubmitGuru_Click);
            // 
            // txtNama
            // 
            this.txtNama.Location = new System.Drawing.Point(434, 137);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(194, 20);
            this.txtNama.TabIndex = 20;
            // 
            // txtNISN
            // 
            this.txtNISN.Location = new System.Drawing.Point(434, 98);
            this.txtNISN.Name = "txtNISN";
            this.txtNISN.Size = new System.Drawing.Size(194, 20);
            this.txtNISN.TabIndex = 19;
            // 
            // txtHari_Piket
            // 
            this.txtHari_Piket.AutoSize = true;
            this.txtHari_Piket.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHari_Piket.ForeColor = System.Drawing.Color.White;
            this.txtHari_Piket.Location = new System.Drawing.Point(274, 215);
            this.txtHari_Piket.Name = "txtHari_Piket";
            this.txtHari_Piket.Size = new System.Drawing.Size(81, 22);
            this.txtHari_Piket.TabIndex = 18;
            this.txtHari_Piket.Text = "Jurusan";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(274, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 22);
            this.label4.TabIndex = 17;
            this.label4.Text = "Kelas";
            // 
            // txtNam
            // 
            this.txtNam.AutoSize = true;
            this.txtNam.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNam.ForeColor = System.Drawing.Color.White;
            this.txtNam.Location = new System.Drawing.Point(274, 137);
            this.txtNam.Name = "txtNam";
            this.txtNam.Size = new System.Drawing.Size(67, 22);
            this.txtNam.TabIndex = 16;
            this.txtNam.Text = "Nama";
            // 
            // txtaja
            // 
            this.txtaja.AutoSize = true;
            this.txtaja.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaja.ForeColor = System.Drawing.Color.White;
            this.txtaja.Location = new System.Drawing.Point(274, 98);
            this.txtaja.Name = "txtaja";
            this.txtaja.Size = new System.Drawing.Size(52, 22);
            this.txtaja.TabIndex = 15;
            this.txtaja.Text = "NISN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(274, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 22);
            this.label2.TabIndex = 25;
            this.label2.Text = "Jenis Kelamin";
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.Back.FlatAppearance.BorderSize = 0;
            this.Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Back.Location = new System.Drawing.Point(434, 290);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(94, 23);
            this.Back.TabIndex = 26;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(61, 81);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(165, 204);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // txtKelas
            // 
            this.txtKelas.FormattingEnabled = true;
            this.txtKelas.Items.AddRange(new object[] {
            "X Tel 1",
            "X Tel 2",
            "X Tel 3",
            "X Tel 4",
            "XI Tel 1",
            "XI Tel 2",
            "XI Tel 3",
            "XI Tel 4",
            "XII Tel 1",
            "XII Tel 2",
            "XII Tel 3",
            "XII Tel 4"});
            this.txtKelas.Location = new System.Drawing.Point(434, 176);
            this.txtKelas.Name = "txtKelas";
            this.txtKelas.Size = new System.Drawing.Size(194, 21);
            this.txtKelas.TabIndex = 28;
            // 
            // txtJK
            // 
            this.txtJK.FormattingEnabled = true;
            this.txtJK.Items.AddRange(new object[] {
            "Laki-Laki",
            "Perempuan"});
            this.txtJK.Location = new System.Drawing.Point(434, 255);
            this.txtJK.Name = "txtJK";
            this.txtJK.Size = new System.Drawing.Size(194, 21);
            this.txtJK.TabIndex = 29;
            // 
            // txtJurusan
            // 
            this.txtJurusan.FormattingEnabled = true;
            this.txtJurusan.Items.AddRange(new object[] {
            "Transmisi",
            "Akses",
            "TKJ",
            "RPL"});
            this.txtJurusan.Location = new System.Drawing.Point(434, 215);
            this.txtJurusan.Name = "txtJurusan";
            this.txtJurusan.Size = new System.Drawing.Size(194, 21);
            this.txtJurusan.TabIndex = 30;
            // 
            // TambahSiswa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(694, 350);
            this.Controls.Add(this.txtJurusan);
            this.Controls.Add(this.txtJK);
            this.Controls.Add(this.txtKelas);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SubmitGuru);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.txtNISN);
            this.Controls.Add(this.txtHari_Piket);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtNam);
            this.Controls.Add(this.txtaja);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TambahSiswa";
            this.Text = "TambahSiswa";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SubmitGuru;
        private System.Windows.Forms.TextBox txtNama;
        private System.Windows.Forms.TextBox txtNISN;
        private System.Windows.Forms.Label txtHari_Piket;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label txtNam;
        private System.Windows.Forms.Label txtaja;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox txtKelas;
        private System.Windows.Forms.ComboBox txtJK;
        private System.Windows.Forms.ComboBox txtJurusan;
    }
}