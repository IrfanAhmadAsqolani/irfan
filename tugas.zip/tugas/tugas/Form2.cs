﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas
{
    public partial class Form2 : Form
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
                

        }

        private void quit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}
