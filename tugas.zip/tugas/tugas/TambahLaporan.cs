﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas
{
    public partial class TambahLaporan : Form
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public TambahLaporan()
        {
            InitializeComponent();
        }

        private void SubmitLaporan_Click(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            Laporant pl = new Laporant();
            
            pl.NISN = int.Parse(txtNISN.Text);
            pl.NIGN = int.Parse(txtNIGN.Text);
            pl.ID_Pelanggaran = int.Parse(txtIDpel.Text);
            pl.Kode_Pelanggaran = txtKode.Text;
            db.Laporants.InsertOnSubmit(pl);

            db.SubmitChanges();
            MessageBox.Show("Data berhasil di simpan");            
            txtNISN.Clear();
            txtNIGN.Clear();
            txtIDpel.Clear();
            
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
        }        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIDpel_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNIGN_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNISN_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIDlap_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
