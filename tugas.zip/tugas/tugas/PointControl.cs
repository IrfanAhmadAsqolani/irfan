﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas
{
    public partial class PointControl : UserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public PointControl()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void PointControl_Load(object sender, EventArgs e)
        {
            var Point = (
         from x in db.Points
         select new
         {
             x.Kode_Pelanggaran,
             x.Jenis_Pelanggaran,
             x.Keterangan,
             x.Jumlah_Point
         }).Distinct();
            dataGridView1.DataSource = Point;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var searchData = (
            from x in db.Points
            select x);

            var searchName = (
                searchData.Where(c => c.Kode_Pelanggaran.Contains(textBox1.Text)
                || c.Jenis_Pelanggaran.Contains(textBox1.Text)
                || c.Keterangan.Contains(textBox1.Text)
                || c.Jumlah_Point.ToString().Contains(textBox1.Text))
                );
            dataGridView1.Rows.Clear();
            dataGridView1.DataSource = searchName;
        }
    }
}
