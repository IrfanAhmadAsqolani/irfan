﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas
{
    public partial class InformationControl : UserControl
    {
        public string currentGrid = "";
        DataClasses1DataContext db = new DataClasses1DataContext();
        public InformationControl()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonLaporan_Click(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            currentGrid = "laporan";
            var Pelanggaran = (
          from x in db.Laporants          
          join f in db.Siswas
          on x.NISN equals f.NISN
          join d in db.Guruds
          on x.NIGN equals d.NIGN
          join t in db.Pelanggarans
          on x.ID_Pelanggaran equals t.ID_Pelanggaran
          join s in db.Points
          on x.Kode_Pelanggaran equals s.Kode_Pelanggaran
          

          select new
          {
              x.ID_Laporan,
              f.NISN,
              f.Nama,
              f.Kelas,
              f.Jurusan,
              f.Jenis_Kelamin,
              d.Nama_Guru,
              t.ID_Pelanggaran,
              t.Kode_Pelanggaran,
              t.Waktu_Kejadian,
              s.Jenis_Pelanggaran,
              s.Keterangan,
              s.Jumlah_Point
              
          });
            dataGridView1.DataSource = Pelanggaran;
        }

        private void buttonSiswa_Click(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            currentGrid = "siswa";
            var Siswa = (
          from x in db.Siswas
          select new
          {

              x.NISN,
              x.Nama,
              x.Kelas,
              x.Jurusan,
              x.Jenis_Kelamin
          }).Distinct();
            dataGridView1.DataSource = Siswa;
        }

        private void buttonGuru_Click(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            currentGrid = ("Guru");
            var Guru = (
          from x in db.Guruds
          select new
          {
              x.NIGN,
              x.Nama_Guru,
              x.Kelas,
              x.Hari_Piket
          }).Distinct();
            dataGridView1.DataSource = Guru;
        }

        private void buttonPelanggaran_Click(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            currentGrid = ("Pelanggaran");
            var Point = (
          from x in db.Pelanggarans
          join g in db.Siswas
          on x.NISN equals g.NISN
          join j in db.Points
          on x.Kode_Pelanggaran equals j.Kode_Pelanggaran
          select new
          {
              x.ID_Pelanggaran,
              x.NISN,
              g.Nama,
              g.Kelas,
              g.Jurusan,
              g.Jenis_Kelamin,
              x.Kode_Pelanggaran,
              j.Jenis_Pelanggaran,
              j.Keterangan,
              j.Jumlah_Point,
              x.Waktu_Kejadian
          }).Distinct();
            dataGridView1.DataSource = Point;
        }

        private void buttonPoint_Click(object sender, EventArgs e)
        {
            
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            if (currentGrid == "siswa")
            {
                var searchData = (
            from x in db.Siswas
            select x);

                var searchName = (
                    searchData.Where(c => c.Nama.Contains(textBox1.Text)
                    || c.Jenis_Kelamin.Contains(textBox1.Text)
                    || c.Kelas.Contains(textBox1.Text)
                    || c.Jurusan.Contains(textBox1.Text)
                    || c.NISN.ToString().Contains(textBox1.Text))
                    );
                dataGridView1.Rows.Clear();
                dataGridView1.DataSource = searchName;
            }
            else if (currentGrid == "Guru")
            {
                db = new DataClasses1DataContext();
                var searchData = (
            from x in db.Guruds
            select x);

                var searchName = (
                    searchData.Where(c => c.Nama_Guru.Contains(textBox1.Text)
                    || c.Hari_Piket.Contains(textBox1.Text)
                    || c.Kelas.Contains(textBox1.Text)                    
                    || c.NIGN.ToString().Contains(textBox1.Text))
                    );
                dataGridView1.Rows.Clear();
                dataGridView1.DataSource = searchName;
            }
            else if (currentGrid == "Pelanggaran")
            {
                db = new DataClasses1DataContext();
                var searchData = (
            from x in db.Pelanggarans
            select x);

                var searchName = (
                    searchData.Where(c => c.Kode_Pelanggaran.Contains(textBox1.Text)
                    || c.ID_Pelanggaran.ToString().Contains(textBox1.Text)                    
                    || c.NISN.ToString().Contains(textBox1.Text))
                    );
                dataGridView1.Rows.Clear();
                dataGridView1.DataSource = searchName;
            }
            else if (currentGrid == "laporan")
            {
                db = new DataClasses1DataContext();
                var searchData = (
            from x in db.Laporants
            select x);

                var searchName = (
                    searchData.Where(c => c.Kode_Pelanggaran.Contains(textBox1.Text)
                    || c.ID_Pelanggaran.ToString().Contains(textBox1.Text)
                    || c.ID_Laporan.ToString().Contains(textBox1.Text)
                    || c.NISN.ToString().Contains(textBox1.Text)
                    || c.NIGN.ToString().Contains(textBox1.Text))
                    );
                dataGridView1.Rows.Clear();
                dataGridView1.DataSource = searchName;
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            if (currentGrid == "laporan")
            {
                db = new DataClasses1DataContext();
                int id = int.Parse(dataGridView1.SelectedRows[0].Cells["ID_laporan"].Value.ToString());
                var deleteLaporan =
                    from laporan in db.Laporants
                    where laporan.ID_Laporan == id
                    select laporan;

                foreach (var l in deleteLaporan)
                {
                    db.Laporants.DeleteOnSubmit(l);
                }

                db.SubmitChanges();

                var Pelanggaran = (
              from x in db.Laporants
              join f in db.Siswas
              on x.NISN equals f.NISN
              join d in db.Guruds
              on x.NIGN equals d.NIGN
              join t in db.Pelanggarans
              on x.ID_Pelanggaran equals t.ID_Pelanggaran

              from y in db.Pelanggarans
              join s in db.Points
              on y.Kode_Pelanggaran equals s.Kode_Pelanggaran

              select new
              {
                  x.ID_Laporan,
                  f.NISN,
                  f.Nama,
                  f.Kelas,
                  f.Jurusan,
                  f.Jenis_Kelamin,
                  d.Nama_Guru,
                  t.ID_Pelanggaran,
                  t.Kode_Pelanggaran,
                  t.Waktu_Kejadian,
                  s.Jenis_Pelanggaran,
                  s.Keterangan,
                  s.Jumlah_Point
              }).Distinct();
                dataGridView1.DataSource = Pelanggaran;

            } else if (currentGrid == "siswa")
            {
                db = new DataClasses1DataContext();
                int id = int.Parse(dataGridView1.SelectedRows[0].Cells["NISN"].Value.ToString());
                var deleteSiswa =
                    from siswa in db.Siswas
                    where siswa.NISN == id
                    select siswa;

                foreach (var l in deleteSiswa)
                {
                    db.Siswas.DeleteOnSubmit(l);
                }

                db.SubmitChanges();
                var Siswa = (
              from x in db.Siswas
              select new
              {

                  x.NISN,
                  x.Nama,
                  x.Kelas,
                  x.Jurusan,
                  x.Jenis_Kelamin
              }).Distinct();
                dataGridView1.DataSource = Siswa;

            }else if (currentGrid == "Guru")
            {
                db = new DataClasses1DataContext();
                int id = int.Parse(dataGridView1.SelectedRows[0].Cells["NIGN"].Value.ToString());
                var deleteGuru =
                    from guru in db.Guruds
                    where guru.NIGN == id
                    select guru;

                foreach (var l in deleteGuru)
                {
                    db.Guruds.DeleteOnSubmit(l);
                }

                db.SubmitChanges();
                    var Guru = (
                  from x in db.Guruds
                  select new
                  {
                      x.NIGN,
                      x.Nama_Guru,
                      x.Kelas,
                      x.Hari_Piket
                  }).Distinct();
                    dataGridView1.DataSource = Guru;

            }else if (currentGrid == "Pelanggaran" )
            {
                db = new DataClasses1DataContext();
                int id = int.Parse(dataGridView1.SelectedRows[0].Cells["ID_Pelanggaran"].Value.ToString());
                var deletePelanggaran =
                    from pelanggaran in db.Pelanggarans
                    where pelanggaran.ID_Pelanggaran == id
                    select pelanggaran;

                foreach (var l in deletePelanggaran)
                {
                    db.Pelanggarans.DeleteOnSubmit(l);
                }

                db.SubmitChanges();
                    var Point = (
              from x in db.Pelanggarans
              join g in db.Siswas
              on x.NISN equals g.NISN
              join j in db.Points
              on x.Kode_Pelanggaran equals j.Kode_Pelanggaran
              select new
              {
                  x.ID_Pelanggaran,
                  x.NISN,
                  g.Nama,
                  g.Kelas,
                  g.Jurusan,
                  g.Jenis_Kelamin,
                  x.Kode_Pelanggaran,
                  j.Jenis_Pelanggaran,
                  j.Keterangan,
                  j.Jumlah_Point,
                  x.Waktu_Kejadian
              }).Distinct();
                    dataGridView1.DataSource = Point;
            }

        }

        private void buttongrafik_Click(object sender, EventArgs e)
        {
            
        }
    }
}

