﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas
{
    public partial class TambahGuru : Form
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public TambahGuru()
        {
            InitializeComponent();
        }

        private void SubmitGuru_Click(object sender, EventArgs e)
        {
            Gurud pl = new Gurud();

            pl.NIGN = int.Parse(txtNIGN2.Text);
            pl.Nama_Guru = txtName.Text;
            pl.Kelas = txtKelas.Text;
            pl.Hari_Piket = txtHarket.Text;
            db.Guruds.InsertOnSubmit(pl);

            db.SubmitChanges();
            MessageBox.Show("Data berhasil di simpan");
            txtNIGN2.Clear();
            txtName.Clear();
            txtKelas.Clear();
            txtHarket.Clear();
        }

        private void SubmitLogin_Click(object sender, EventArgs e)
        {
            Login pl = new Login();

            pl.Username = txtUser.Text;
            pl.Password = txtPass.Text;
            pl.Role = txtRole.Text;
            db.Logins.InsertOnSubmit(pl);

            db.SubmitChanges();
            MessageBox.Show("Data berhasil di simpan");
            txtUser.Clear();
            txtPass.Clear();
            
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
