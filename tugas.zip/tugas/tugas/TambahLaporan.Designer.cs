﻿namespace tugas
{
    partial class TambahLaporan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TambahLaporan));
            this.label1 = new System.Windows.Forms.Label();
            this.SubmitLaporan = new System.Windows.Forms.Button();
            this.txtNIGN = new System.Windows.Forms.TextBox();
            this.txtNISN = new System.Windows.Forms.TextBox();
            this.txtHari_Piket = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNama = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Back = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtKode = new System.Windows.Forms.ComboBox();
            this.txtIDpel = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(208, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(267, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Penambahan Data Laporan";
            // 
            // SubmitLaporan
            // 
            this.SubmitLaporan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.SubmitLaporan.FlatAppearance.BorderSize = 0;
            this.SubmitLaporan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SubmitLaporan.Location = new System.Drawing.Point(562, 294);
            this.SubmitLaporan.Name = "SubmitLaporan";
            this.SubmitLaporan.Size = new System.Drawing.Size(94, 23);
            this.SubmitLaporan.TabIndex = 42;
            this.SubmitLaporan.Text = "Submit";
            this.SubmitLaporan.UseVisualStyleBackColor = false;
            this.SubmitLaporan.Click += new System.EventHandler(this.SubmitLaporan_Click);
            // 
            // txtNIGN
            // 
            this.txtNIGN.Location = new System.Drawing.Point(423, 175);
            this.txtNIGN.Name = "txtNIGN";
            this.txtNIGN.Size = new System.Drawing.Size(233, 20);
            this.txtNIGN.TabIndex = 40;
            this.txtNIGN.TextChanged += new System.EventHandler(this.txtNIGN_TextChanged);
            // 
            // txtNISN
            // 
            this.txtNISN.Location = new System.Drawing.Point(423, 138);
            this.txtNISN.Name = "txtNISN";
            this.txtNISN.Size = new System.Drawing.Size(233, 20);
            this.txtNISN.TabIndex = 39;
            this.txtNISN.TextChanged += new System.EventHandler(this.txtNISN_TextChanged);
            // 
            // txtHari_Piket
            // 
            this.txtHari_Piket.AutoSize = true;
            this.txtHari_Piket.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHari_Piket.ForeColor = System.Drawing.Color.White;
            this.txtHari_Piket.Location = new System.Drawing.Point(233, 215);
            this.txtHari_Piket.Name = "txtHari_Piket";
            this.txtHari_Piket.Size = new System.Drawing.Size(155, 22);
            this.txtHari_Piket.TabIndex = 37;
            this.txtHari_Piket.Text = "ID Pelanggaran";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(233, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 22);
            this.label4.TabIndex = 36;
            this.label4.Text = "NIGN";
            // 
            // txtNama
            // 
            this.txtNama.AutoSize = true;
            this.txtNama.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNama.ForeColor = System.Drawing.Color.White;
            this.txtNama.Location = new System.Drawing.Point(233, 138);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(52, 22);
            this.txtNama.TabIndex = 35;
            this.txtNama.Text = "NISN";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(694, 38);
            this.panel1.TabIndex = 33;
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.Back.FlatAppearance.BorderSize = 0;
            this.Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Back.Location = new System.Drawing.Point(423, 294);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(95, 23);
            this.Back.TabIndex = 48;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(233, 255);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 22);
            this.label2.TabIndex = 49;
            this.label2.Text = "Kode Pelanggaran";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 90);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(165, 199);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 51;
            this.pictureBox1.TabStop = false;
            // 
            // txtKode
            // 
            this.txtKode.FormattingEnabled = true;
            this.txtKode.Items.AddRange(new object[] {
            "A101",
            "A102",
            "A103",
            "A104",
            "A105",
            "A106",
            "A107",
            "A108",
            "A201",
            "A202",
            "A203",
            "A204",
            "A205",
            "A206",
            "A301",
            "A401",
            "A501",
            "B101",
            "B102",
            "B103",
            "B104",
            "B105",
            "B201",
            "B202",
            "B203",
            "B204",
            "B205",
            "B206",
            "B207",
            "B208",
            "C001",
            "C002",
            "C003",
            "C004",
            "C005",
            "C006",
            "C007",
            "C008",
            "C009",
            "C010",
            "C011",
            "C012",
            "C013",
            "C014",
            "C015",
            "C016",
            "C017",
            "C018",
            "C019",
            "C020",
            "C021",
            "C022",
            "C023",
            "C024",
            "C025",
            "C026",
            "C027",
            "C028",
            "C029",
            "C030",
            "C031",
            "C032",
            "C033",
            "C034",
            "C035",
            "C036",
            "C037",
            "C038",
            "C039"});
            this.txtKode.Location = new System.Drawing.Point(423, 255);
            this.txtKode.Name = "txtKode";
            this.txtKode.Size = new System.Drawing.Size(233, 21);
            this.txtKode.TabIndex = 52;
            // 
            // txtIDpel
            // 
            this.txtIDpel.Location = new System.Drawing.Point(423, 215);
            this.txtIDpel.Name = "txtIDpel";
            this.txtIDpel.Size = new System.Drawing.Size(233, 20);
            this.txtIDpel.TabIndex = 41;
            this.txtIDpel.TextChanged += new System.EventHandler(this.txtIDpel_TextChanged);
            // 
            // TambahLaporan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(694, 350);
            this.Controls.Add(this.txtKode);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.SubmitLaporan);
            this.Controls.Add(this.txtIDpel);
            this.Controls.Add(this.txtNIGN);
            this.Controls.Add(this.txtNISN);
            this.Controls.Add(this.txtHari_Piket);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TambahLaporan";
            this.Text = "Form4";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SubmitLaporan;
        private System.Windows.Forms.TextBox txtNIGN;
        private System.Windows.Forms.TextBox txtNISN;
        private System.Windows.Forms.Label txtHari_Piket;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label txtNama;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox txtKode;
        private System.Windows.Forms.TextBox txtIDpel;
    }
}