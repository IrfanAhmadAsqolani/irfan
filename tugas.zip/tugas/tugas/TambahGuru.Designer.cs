﻿namespace tugas
{
    partial class TambahGuru
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TambahGuru));
            this.SubmitLogin = new System.Windows.Forms.Button();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SubmitGuru = new System.Windows.Forms.Button();
            this.txtHarket = new System.Windows.Forms.TextBox();
            this.txtKelas = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtNIGN2 = new System.Windows.Forms.TextBox();
            this.txtHari_Piket = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNama = new System.Windows.Forms.Label();
            this.txtNIGN = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Back = new System.Windows.Forms.Button();
            this.txtRole = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // SubmitLogin
            // 
            this.SubmitLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.SubmitLogin.FlatAppearance.BorderSize = 0;
            this.SubmitLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SubmitLogin.Location = new System.Drawing.Point(588, 265);
            this.SubmitLogin.Name = "SubmitLogin";
            this.SubmitLogin.Size = new System.Drawing.Size(94, 23);
            this.SubmitLogin.TabIndex = 39;
            this.SubmitLogin.Text = "Submit";
            this.SubmitLogin.UseVisualStyleBackColor = false;
            this.SubmitLogin.Click += new System.EventHandler(this.SubmitLogin_Click);
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(546, 163);
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(136, 20);
            this.txtPass.TabIndex = 37;
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(546, 120);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(136, 20);
            this.txtUser.TabIndex = 36;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(439, 204);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 22);
            this.label2.TabIndex = 35;
            this.label2.Text = "Role";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(439, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 22);
            this.label3.TabIndex = 34;
            this.label3.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(439, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 22);
            this.label5.TabIndex = 33;
            this.label5.Text = "Username";
            // 
            // SubmitGuru
            // 
            this.SubmitGuru.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.SubmitGuru.FlatAppearance.BorderSize = 0;
            this.SubmitGuru.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SubmitGuru.Location = new System.Drawing.Point(116, 265);
            this.SubmitGuru.Name = "SubmitGuru";
            this.SubmitGuru.Size = new System.Drawing.Size(94, 23);
            this.SubmitGuru.TabIndex = 32;
            this.SubmitGuru.Text = "Submit";
            this.SubmitGuru.UseVisualStyleBackColor = false;
            this.SubmitGuru.Click += new System.EventHandler(this.SubmitGuru_Click);
            // 
            // txtHarket
            // 
            this.txtHarket.Location = new System.Drawing.Point(116, 225);
            this.txtHarket.Name = "txtHarket";
            this.txtHarket.Size = new System.Drawing.Size(147, 20);
            this.txtHarket.TabIndex = 31;
            // 
            // txtKelas
            // 
            this.txtKelas.Location = new System.Drawing.Point(116, 185);
            this.txtKelas.Name = "txtKelas";
            this.txtKelas.Size = new System.Drawing.Size(147, 20);
            this.txtKelas.TabIndex = 30;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(116, 145);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(147, 20);
            this.txtName.TabIndex = 29;
            // 
            // txtNIGN2
            // 
            this.txtNIGN2.Location = new System.Drawing.Point(116, 105);
            this.txtNIGN2.Name = "txtNIGN2";
            this.txtNIGN2.Size = new System.Drawing.Size(147, 20);
            this.txtNIGN2.TabIndex = 28;
            // 
            // txtHari_Piket
            // 
            this.txtHari_Piket.AutoSize = true;
            this.txtHari_Piket.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHari_Piket.ForeColor = System.Drawing.Color.White;
            this.txtHari_Piket.Location = new System.Drawing.Point(12, 225);
            this.txtHari_Piket.Name = "txtHari_Piket";
            this.txtHari_Piket.Size = new System.Drawing.Size(93, 22);
            this.txtHari_Piket.TabIndex = 27;
            this.txtHari_Piket.Text = "Hari Piket";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(12, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 22);
            this.label4.TabIndex = 26;
            this.label4.Text = "Kelas";
            // 
            // txtNama
            // 
            this.txtNama.AutoSize = true;
            this.txtNama.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNama.ForeColor = System.Drawing.Color.White;
            this.txtNama.Location = new System.Drawing.Point(12, 145);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(67, 22);
            this.txtNama.TabIndex = 25;
            this.txtNama.Text = "Nama";
            // 
            // txtNIGN
            // 
            this.txtNIGN.AutoSize = true;
            this.txtNIGN.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNIGN.ForeColor = System.Drawing.Color.White;
            this.txtNIGN.Location = new System.Drawing.Point(12, 105);
            this.txtNIGN.Name = "txtNIGN";
            this.txtNIGN.Size = new System.Drawing.Size(60, 22);
            this.txtNIGN.TabIndex = 24;
            this.txtNIGN.Text = "NIGN";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(280, 88);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(153, 159);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(694, 38);
            this.panel1.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(229, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(235, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Penambahan Data Guru";
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(172)))), ((int)(((byte)(0)))));
            this.Back.FlatAppearance.BorderSize = 0;
            this.Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Back.Location = new System.Drawing.Point(290, 265);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(143, 23);
            this.Back.TabIndex = 40;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // txtRole
            // 
            this.txtRole.FormattingEnabled = true;
            this.txtRole.Items.AddRange(new object[] {
            "Guru BK",
            "Guru Piket",
            "Wali Kelas"});
            this.txtRole.Location = new System.Drawing.Point(546, 208);
            this.txtRole.Name = "txtRole";
            this.txtRole.Size = new System.Drawing.Size(136, 21);
            this.txtRole.TabIndex = 41;
            // 
            // TambahGuru
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(694, 350);
            this.Controls.Add(this.txtRole);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.SubmitLogin);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.SubmitGuru);
            this.Controls.Add(this.txtHarket);
            this.Controls.Add(this.txtKelas);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtNIGN2);
            this.Controls.Add(this.txtHari_Piket);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.txtNIGN);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TambahGuru";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SubmitLogin;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button SubmitGuru;
        private System.Windows.Forms.TextBox txtHarket;
        private System.Windows.Forms.TextBox txtKelas;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtNIGN2;
        private System.Windows.Forms.Label txtHari_Piket;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label txtNama;
        private System.Windows.Forms.Label txtNIGN;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.ComboBox txtRole;
    }
}