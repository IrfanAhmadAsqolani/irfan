﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas
{
    public partial class Form1 : Form
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public Form1()
        {
            InitializeComponent();
        }

        private void blogin_Click(object sender, EventArgs e)
        {
            var getData =
            (
                from x in db.Logins
                where x.Username == txtuser.Text && x.Password == txtpass.Text && x.Role == cblogin.SelectedItem.ToString()
                select x
            );

            if (getData.Count() == 1)
            {
                MessageBox.Show("Selamat Datang di Aplikasi Point Siswa Kami" + "\nAnda " + txtuser.Text + " Login Menggunakan akun" + "\nUsername:" + txtuser.Text + "\nPassword: " + txtpass.Text + "\nLogin as:" + cblogin.Text);
                Dashboard d = new Dashboard();
                d.Show();
                this.Hide();

            }
            else if (cblogin.Text == "Guru Piket")
            {
                MessageBox.Show("Selamat Datang di Aplikasi Point Siswa Kami" + "\nAnda " + txtuser.Text + " Login Menggunakan akun" + "\nUsername:" + txtuser.Text + "\nPassword: " + txtpass.Text + "\nLogin as:" + cblogin.Text);
                Dashboard d = new Dashboard();
                d.Show();
                this.Hide();
            }
            else if (cblogin.Text == "Wali Kelas")
            {
                MessageBox.Show("Selamat Datang di Aplikasi Point Siswa Kami" + "\nAnda " + txtuser.Text + " Login Menggunakan akun" + "\nUsername:" + txtuser.Text + "\nPassword: " + txtpass.Text + "\nLogin as:" + cblogin.Text);
                Dashboard d = new Dashboard();
                d.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show(" Login Gagal Akun Anda Tidak Ditemukan");
                Form1 d = new Form1();
                d.Show();
                this.Hide();
            }
            }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
    }


